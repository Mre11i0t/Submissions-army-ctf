import os
import pickle
import base64
from Crypto.Cipher import AES
#shared secret key between client and server, this is under the assumption that attacker  does not know this shared secret key
SHARED_SECRET = b"verystrongsecrethere"
#lambda function to clean input
cleaninput = lambda s : s[:-ord(s[len(s)-1:])]

#decrypt data
def decrypt_data(enc_obj):
    enc_obj = base64.b64decode(enc_obj)
    iv = enc_obj[:16]
    cipher = AES.new(SHARED_SECRET, AES.MODE_CBC, iv)
    return cleaninput(cipher.decrypt( enc_obj[16:]))

#reverse the data
def reverse_fun():
      with open("users.json","rb") as f:
          enc_data = f.read()
      
      try:
            data = decrypt_data(enc_data)
      except Exception as e:
            return f"Inconsistent users.json file. Aborting!! {e}"
      else:
            d = pickle.loads(data)
            return d


if __name__ == '__main__':
      print(reverse_fun())
