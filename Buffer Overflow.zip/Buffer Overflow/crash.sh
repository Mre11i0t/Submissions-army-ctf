# Solution by mpkarthick2002
echo "11" | ./executable